/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.capstone.ics.controller;

import com.capstone.ics.model.Credentials;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Auguste C
 */
public class MainPanelController {

    private final String userModuleStage = "/fxml/UsersManager.fxml";
    private final String siteModuleStage = "/fxml/CompanyModule.fxml";
    private final String inventoryModuleStage = "/fxml/InventoryManager.fxml";
    private final String logModuleStage = "/fxml/AuditLog.fxml";
    
    @FXML
    private Label loggedUserFirstAndLastName;
    
    @FXML 
    private ImageView reportModule,logModule;

    private final StageManager newStage = new StageManager();
    private  Credentials currentLoggedUser;
    
      @FXML
    private void initialize() {
        LoginController user = new LoginController(); 
        currentLoggedUser = user.getLoggedUser();
        managerUserAccess();
        loggedUserFirstAndLastName.setText(user.getCurrentUserFirstAndLastName());
    }

    private void managerUserAccess()
    {
        if(currentLoggedUser.isAccessLogModule() == false)
        {
            logModule.setVisible(false);            
        }
        
        if(currentLoggedUser.isAccessReportModule()==false)
        {
            reportModule.setVisible(false);
        }
    }
    
    @FXML
    private void goToUserManagerWindow(Event onMouseClicked) {
        newStage.nextStage(userModuleStage, "Users Module Manager");
        onMouseClicked.consume();
    }
    
    @FXML
    private void goToSiteManagerWindow(Event onMouseClicked) {
        newStage.nextStage(siteModuleStage, "Site Module Manager");
        onMouseClicked.consume();
    }
    
    @FXML
    private void goToInventoryManagerWindow(Event onMouseClicked) {
        newStage.nextStage(inventoryModuleStage, "Inventory Module Manager");
        onMouseClicked.consume();
    }
    
    @FXML
    private void goToLogManagerWindow(Event onMouseClicked) {
        newStage.nextStage(logModuleStage, "Log Module Manager");
        onMouseClicked.consume();
    }

}
