/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.capstone.ics.controller;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Auguste C
 */
public class ReportModuleController {

    private final Node rootIcon = new ImageView(
            new Image(getClass().getResourceAsStream("/images/Reports.png")));
    
    @FXML
    private TreeView<String> reportTreeView;

    @FXML
    private Label title, description;

    /**
     * Initializes the controller class.
     */
    @FXML
    private void initialize() {

        TreeItem<String> rootItem = new TreeItem<>("Inventory Reports");
        reportTreeView.getSelectionModel().selectedItemProperty().addListener(
                (Observable, oldValue, newValue) -> setTitleAndDescription(newValue));

        TreeItem<String> type1 = new TreeItem<>("Inventory Summary");
        TreeItem<String> type2 = new TreeItem<>("Product Price List");
        rootItem.getChildren().addAll(type1, type2);
        rootItem.setExpanded(true);

        reportTreeView.setRoot(rootItem);

    }

    private void handleMouseClick() {

    }

    private void setTitleAndDescription(TreeItem<String> newValue) {
        if (newValue.getValue().equals("Inventory Summary")) {
            title.setText("Inventory Summary");
            description.setText("The summary of all products added by all users.");
        }
        if (newValue.getValue().equals("Product Price List")) {
            title.setText("Product Price List");
            description.setText("List of all products along with their price.");
        }

    }

}
